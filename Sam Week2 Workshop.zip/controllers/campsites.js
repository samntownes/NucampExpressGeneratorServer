const Campsite = require("../models/campsite");

module.exports = {
  getAllCampsites: async (req, res, next) => {
    try {
      let allCampsites = await Campsite.find();
      res.send(allCampsites);
    } catch (err) {
      next(err);
    }
  },
  createNewCampsite: async (req, res, next) => {
    try {
      let newCampsite = await Campsite.create(req.body);
      console.log("Campsite Created ", newCampsite);
      res.send(newCampsite);
    } catch {
      err => next(err);
    }
  },
  deleteAllCampsites: (req, res, next) => {
    Campsite.deleteMany()
      .then(response => {
        res.statusCode = 200;
        res.setHeader("Content-Type", "application/json");
        res.json(response);
      })
      .catch(err => next(err));
  }
};
